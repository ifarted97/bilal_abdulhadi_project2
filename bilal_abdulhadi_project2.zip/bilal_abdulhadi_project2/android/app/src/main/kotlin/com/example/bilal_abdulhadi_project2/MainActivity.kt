package com.example.bilal_abdulhadi_project2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
