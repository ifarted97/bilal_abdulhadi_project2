const host = "attendance-manager-app.onrender.com";
const hostedSiteLink = "https://attendance-manager-app.onrender.com";
